import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login");

  const userId = (session.user as any).id;
  const plan = (session.user as any).plan as string;

  const projects = await prisma.project.findMany({
    where: { userId },
    orderBy: { updatedAt: "desc" },
  });

  return (
    <main className="mx-auto max-w-3xl p-6">
      <header className="mb-8 flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Your projects</h1>
        <div className="flex items-center gap-3">
          <span className="rounded-full bg-gray-100 px-3 py-1 text-sm">{plan} plan</span>
          {plan === "FREE" && (
            <Link href="/dashboard/upgrade" className="text-sm text-blue-600 underline">
              Upgrade for custom domain
            </Link>
          )}
        </div>
      </header>

      <Link
        href="/dashboard/chat/new"
        className="mb-6 inline-block rounded bg-black px-4 py-2 text-white"
      >
        + New project
      </Link>

      <ul className="space-y-3">
        {projects.map((p) => (
          <li key={p.id} className="rounded border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{p.name}</p>
                <p className="text-sm text-gray-500">
                  {p.customDomain || `${p.name}.yourweb.com`} — {p.status}
                </p>
              </div>
              <Link href={`/dashboard/chat/${p.id}`} className="text-blue-600 underline">
                Open
              </Link>
            </div>
          </li>
        ))}
        {projects.length === 0 && (
          <p className="text-gray-500">No projects yet — start one above.</p>
        )}
      </ul>
    </main>
  );
}
