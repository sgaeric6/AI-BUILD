"use client";

export default function UpgradePage() {
  async function upgrade(plan: "PRO" | "ADVANCED") {
    const res = await fetch("/api/paystack/init", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ plan }),
    });
    const { authorizationUrl } = await res.json();
    window.location.href = authorizationUrl; // redirect to Paystack checkout
  }

  return (
    <main className="mx-auto max-w-xl p-6">
      <h1 className="mb-6 text-2xl font-semibold">Upgrade your plan</h1>

      <div className="space-y-4">
        <div className="rounded border p-4">
          <h2 className="font-medium">Pro — custom domain</h2>
          <p className="mb-3 text-sm text-gray-500">
            Connect your own domain (yourapp.com) to your project.
          </p>
          <button onClick={() => upgrade("PRO")} className="rounded bg-black px-4 py-2 text-white">
            Upgrade to Pro
          </button>
        </div>

        <div className="rounded border p-4">
          <h2 className="font-medium">Advanced — always-on hosting</h2>
          <p className="mb-3 text-sm text-gray-500">
            Custom domain + your app never idles, plus higher AI usage limits.
          </p>
          <button
            onClick={() => upgrade("ADVANCED")}
            className="rounded bg-black px-4 py-2 text-white"
          >
            Upgrade to Advanced
          </button>
        </div>
      </div>
    </main>
  );
}
