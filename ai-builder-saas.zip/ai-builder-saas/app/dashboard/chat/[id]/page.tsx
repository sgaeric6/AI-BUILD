"use client";

import { useState } from "react";

export default function ProjectChatPage({ params }: { params: { id: string } }) {
  const [prompt, setPrompt] = useState("");
  const [log, setLog] = useState<{ role: string; content: string }[]>([]);
  const [loading, setLoading] = useState(false);

  async function send() {
    if (!prompt.trim()) return;
    setLog((l) => [...l, { role: "user", content: prompt }]);
    setLoading(true);
    const currentPrompt = prompt;
    setPrompt("");

    const res = await fetch("/api/ai/build", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ projectId: params.id, prompt: currentPrompt }),
    });
    const data = await res.json();

    setLog((l) => [
      ...l,
      {
        role: "assistant",
        content: res.ok
          ? `Done. Updated: ${data.filesChanged?.join(", ")}`
          : `Error: ${data.error}`,
      },
    ]);
    setLoading(false);
  }

  return (
    <main className="mx-auto flex h-screen max-w-2xl flex-col p-6">
      <h1 className="mb-4 text-xl font-semibold">Tell the AI what to build</h1>

      <div className="flex-1 space-y-3 overflow-y-auto">
        {log.map((m, i) => (
          <div
            key={i}
            className={m.role === "user" ? "text-right" : "text-left"}
          >
            <span
              className={`inline-block rounded px-3 py-2 ${
                m.role === "user" ? "bg-black text-white" : "bg-gray-100"
              }`}
            >
              {m.content}
            </span>
          </div>
        ))}
        {loading && <p className="text-gray-400">Building…</p>}
      </div>

      <div className="mt-4 flex gap-2">
        <input
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="e.g. Add a pricing page with 3 tiers"
          className="flex-1 rounded border px-3 py-2"
        />
        <button
          onClick={send}
          disabled={loading}
          className="rounded bg-black px-4 py-2 text-white disabled:opacity-50"
        >
          Send
        </button>
      </div>
    </main>
  );
}
