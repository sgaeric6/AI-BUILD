# AI Builder SaaS — starter scaffold

A working starting point for: users sign up → get a dashboard → chat with AI →
AI writes code → code deploys automatically → free users get a subdomain,
paying users can attach a custom domain (paid via Paystack).

**This is a scaffold, not a finished product.** It wires up every integration
end-to-end so you can run it, see it work, and extend it — not a fully
polished commercial platform. Treat the AI code generation, error recovery,
and UI as a first version to iterate on.

## How it actually works

1. User signs up with email (magic link, no password) via NextAuth.
2. User opens a project and types what they want built.
3. `/api/ai/build` sends the conversation to your chosen AI provider
   (defaults to OpenRouter's free tier), gets back file contents, commits
   them to a GitHub repo created for that project, then either creates a new
   Vercel project (first build) or triggers a redeploy (later builds).
4. Free-plan users get `<subdomain>.yourweb.com` via Vercel's domain API,
   aliased to your wildcard domain.
5. Paying users can submit their own domain; you call Vercel's domains API
   to attach it and show them the DNS records to set at their registrar.
6. Paystack webhook listens for successful payments and upgrades the user's
   plan in the database.

## Accounts you need (all free to create)

| Service | What for | Where to get keys |
|---|---|---|
| Postgres DB | user/project data | Vercel Postgres, Supabase, or Neon (all free tier) |
| OpenRouter (or Groq/Gemini) | AI code generation | https://openrouter.ai/keys |
| GitHub | stores generated code per project | https://github.com/settings/tokens (repo scope) |
| Vercel | hosts your app + deploys user projects | https://vercel.com/account/tokens |
| SMTP provider | sends magic-link emails | Resend, Postmark, or similar |
| Paystack | payments | https://dashboard.paystack.com → Settings → API Keys |

**Never paste real API keys into chat, code comments, or commit them to
GitHub.** They only ever go into `.env` locally or Vercel's Environment
Variables panel in production.

## Setup

```bash
npm install
cp .env.example .env   # then fill in your real values
npm run db:push        # creates tables in your Postgres database
npm run dev
```

## Deploying

1. Push this repo to your own GitHub repo.
2. Import it in Vercel.
3. Add every variable from `.env.example` in Vercel → Settings →
   Environment Variables (use your real values, not the placeholders).
4. In Vercel → your project → Domains, add `*.yourweb.com` as a wildcard
   domain, pointed at this project — this is what lets you hand out
   `username.yourweb.com` subdomains.
5. Set your Paystack webhook URL to `https://yourweb.com/api/paystack/webhook`.

## Things that need real decisions before this is production-ready

- **"Sleep after inactivity" for free-tier apps**: Vercel serverless
  functions don't have a literal sleep timer like Heroku dynos did. The
  practical way to create a free-vs-paid difference is: free apps stay on
  Vercel's standard Hobby-tier limits (cold starts, lower concurrency),
  paid apps get a production domain that stays warm. Trying to force an
  artificial "sleep every N seconds" isn't how the platform works and would
  fight it more than use it.
- **AI reliability**: free-tier coding models are good but not perfect —
  budget time for prompt tuning and a retry/error-repair loop (have the AI
  see the deploy error and try again) before trusting this for real users.
- **Rate limits**: free AI tiers cap requests/day. For real usage you'll
  want to queue requests, show users their remaining quota, and/or let paid
  plans use a stronger paid model.
- **Repo cleanup**: decide whether to keep every user's generated repo
  forever or archive/delete unused ones — GitHub free accounts have repo
  count limits on some plans.
- **Security**: the AI-generated code runs as a real deployed app. Consider
  scanning generated code for anything that shouldn't ship (secrets,
  malicious patterns) before/after deploy, especially once other people can
  view the deployed apps.
