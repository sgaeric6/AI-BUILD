// Requires PAYSTACK_SECRET_KEY in your Vercel env vars — get it from your
// Paystack dashboard (Settings > API Keys). NEVER commit this key or paste it
// into chat/code — only set it as an environment variable.

const PAYSTACK_API = "https://api.paystack.co";

function headers() {
  return {
    Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
    "Content-Type": "application/json",
  };
}

export async function initializeTransaction(email: string, amountKobo: number, metadata: object) {
  const res = await fetch(`${PAYSTACK_API}/transaction/initialize`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify({
      email,
      amount: amountKobo, // Paystack uses the smallest currency unit (kobo for NGN)
      metadata,
      callback_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,
    }),
  });
  if (!res.ok) throw new Error(`Paystack init failed: ${await res.text()}`);
  return res.json(); // returns { data: { authorization_url, reference, ... } }
}

export async function verifyTransaction(reference: string) {
  const res = await fetch(`${PAYSTACK_API}/transaction/verify/${reference}`, {
    headers: headers(),
  });
  if (!res.ok) throw new Error(`Paystack verify failed: ${await res.text()}`);
  return res.json();
}

// Verifies the X-Paystack-Signature header on incoming webhooks using HMAC SHA512,
// per Paystack's docs — do this before trusting any webhook payload.
export function verifyWebhookSignature(rawBody: string, signature: string): boolean {
  const crypto = require("crypto");
  const hash = crypto
    .createHmac("sha512", process.env.PAYSTACK_SECRET_KEY)
    .update(rawBody)
    .digest("hex");
  return hash === signature;
}
