// lib/ai.ts
//
// Provider-agnostic AI client for the "AI builds your app" feature.
// Defaults to OpenRouter's free tier (OpenAI-compatible API), which currently
// exposes strong free coding models like "qwen/qwen3-coder:free".
//
// To switch providers later, you only change env vars — no code changes:
//   AI_PROVIDER=openrouter | groq | gemini
//   AI_API_KEY=<your key from that provider>
//   AI_MODEL=<model id for that provider>
//
// Free-tier signup (no card required):
//   OpenRouter: https://openrouter.ai/keys
//   Groq:       https://console.groq.com/keys
//   Gemini:     https://aistudio.google.com/apikey
//
// All three providers speak an OpenAI-compatible chat completions format,
// so one fetch call works for all of them — only the base URL changes.

type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

const PROVIDER_BASE_URLS: Record<string, string> = {
  openrouter: "https://openrouter.ai/api/v1/chat/completions",
  groq: "https://api.groq.com/openai/v1/chat/completions",
  gemini: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
};

const DEFAULT_MODELS: Record<string, string> = {
  openrouter: "qwen/qwen3-coder:free",
  groq: "llama-3.3-70b-versatile",
  gemini: "gemini-2.5-flash",
};

export async function generateCode(messages: ChatMessage[]): Promise<string> {
  const provider = process.env.AI_PROVIDER || "openrouter";
  const apiKey = process.env.AI_API_KEY;
  const model = process.env.AI_MODEL || DEFAULT_MODELS[provider];
  const baseUrl = PROVIDER_BASE_URLS[provider];

  if (!apiKey) {
    throw new Error(
      "Missing AI_API_KEY. Sign up free at https://openrouter.ai/keys and add it to your .env"
    );
  }
  if (!baseUrl) {
    throw new Error(`Unknown AI_PROVIDER "${provider}". Use openrouter, groq, or gemini.`);
  }

  const res = await fetch(baseUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
      // OpenRouter asks for these two headers as good practice (not required, but avoids throttling)
      "HTTP-Referer": process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
      "X-Title": "AI Builder SaaS",
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.2,
      max_tokens: 4000,
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`AI provider error (${provider}, ${res.status}): ${errText}`);
  }

  const data = await res.json();
  const content = data?.choices?.[0]?.message?.content;
  if (!content) throw new Error("AI provider returned no content");
  return content;
}

// System prompt used for every build request. Keep this tight — it keeps the
// model from wrapping code in prose and enforces predictable output we can parse.
export const BUILD_SYSTEM_PROMPT = `You are an expert full-stack developer.
The user will describe an app or a change to an existing app.
Respond ONLY with the code changes needed, using this exact format for every file:

===FILE: path/to/file.ext===
<complete file contents>
===END===

Do not include explanations outside this format. Do not use markdown code fences.
If fixing an error, output the full corrected file, not a diff.`;
