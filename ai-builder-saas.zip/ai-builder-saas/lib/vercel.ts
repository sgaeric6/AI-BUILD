// Requires a Vercel API token (https://vercel.com/account/tokens) stored as
// VERCEL_TOKEN in .env, and your Vercel team id as VERCEL_TEAM_ID (optional,
// only needed if the token belongs to a team account).

const VERCEL_API = "https://api.vercel.com";

function authHeaders() {
  return {
    Authorization: `Bearer ${process.env.VERCEL_TOKEN}`,
    "Content-Type": "application/json",
  };
}

function teamQuery() {
  return process.env.VERCEL_TEAM_ID ? `?teamId=${process.env.VERCEL_TEAM_ID}` : "";
}

// Creates a new Vercel project linked to the user's generated GitHub repo.
// On free plan this deploys as a normal Vercel project (subject to Vercel's
// own Hobby-tier serverless limits). On paid plans we attach a production
// custom domain, which keeps it on Vercel's faster/always-on production path.
export async function createVercelProject(name: string, githubRepo: string) {
  const res = await fetch(`${VERCEL_API}/v10/projects${teamQuery()}`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      name,
      gitRepository: { type: "github", repo: githubRepo },
      framework: "nextjs",
    }),
  });
  if (!res.ok) throw new Error(`Vercel project creation failed: ${await res.text()}`);
  return res.json();
}

// Triggers a deployment for an existing Vercel project (e.g. after a new commit).
export async function triggerDeployment(projectName: string, githubRepo: string, ref = "main") {
  const res = await fetch(`${VERCEL_API}/v13/deployments${teamQuery()}`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      name: projectName,
      gitSource: { type: "github", repo: githubRepo, ref },
      target: "production",
    }),
  });
  if (!res.ok) throw new Error(`Vercel deployment failed: ${await res.text()}`);
  return res.json();
}

// Attaches a custom domain to a project — call this once a user on a paid
// plan submits their own domain. Returns DNS records the user must set at
// their registrar (shown back to them in the dashboard).
export async function addCustomDomain(projectIdOrName: string, domain: string) {
  const res = await fetch(
    `${VERCEL_API}/v10/projects/${projectIdOrName}/domains${teamQuery()}`,
    {
      method: "POST",
      headers: authHeaders(),
      body: JSON.stringify({ name: domain }),
    }
  );
  if (!res.ok) throw new Error(`Adding domain failed: ${await res.text()}`);
  return res.json(); // includes verification records to show the user
}

// Polls a deployment until it finishes building (READY or ERROR), or times out.
// Vercel deployment states: QUEUED, BUILDING, READY, ERROR, CANCELED.
export async function waitForDeployment(
  deploymentId: string,
  { timeoutMs = 120_000, intervalMs = 3000 } = {}
): Promise<{ state: string; url?: string }> {
  const start = Date.now();

  while (Date.now() - start < timeoutMs) {
    const res = await fetch(`${VERCEL_API}/v13/deployments/${deploymentId}${teamQuery()}`, {
      headers: authHeaders(),
    });
    if (!res.ok) throw new Error(`Checking deployment status failed: ${await res.text()}`);
    const data = await res.json();

    if (data.readyState === "READY") return { state: "READY", url: data.url };
    if (data.readyState === "ERROR" || data.readyState === "CANCELED") {
      return { state: data.readyState };
    }
    await new Promise((r) => setTimeout(r, intervalMs));
  }

  return { state: "TIMEOUT" };
}

// Fetches build log lines for a failed deployment, trimmed to the parts
// that actually explain the failure (error-level lines), so we can hand a
// short, relevant excerpt back to the AI instead of a huge raw log.
export async function getDeploymentErrorLogs(deploymentId: string): Promise<string> {
  const res = await fetch(
    `${VERCEL_API}/v2/deployments/${deploymentId}/events${teamQuery()}`,
    { headers: authHeaders() }
  );
  if (!res.ok) return "(could not fetch build logs)";

  const events = await res.json();
  const lines: string[] = Array.isArray(events)
    ? events
        .map((e: any) => e?.payload?.text || e?.text)
        .filter(Boolean)
    : [];

  // Keep it short: last ~40 lines is usually enough to show the actual error
  // without blowing the AI's context window on a full build log.
  return lines.slice(-40).join("\n") || "(no build log output captured)";
}

// Adds the free-tier subdomain (e.g. "john.yourweb.com") by aliasing to your
// own wildcard domain project — requires *.yourweb.com added as a wildcard
// domain on your main Vercel project once, in the Vercel dashboard.
export async function addSubdomain(projectIdOrName: string, subdomain: string) {
  const rootDomain = process.env.NEXT_PUBLIC_ROOT_DOMAIN; // e.g. "yourweb.com"
  return addCustomDomain(projectIdOrName, `${subdomain}.${rootDomain}`);
}
